from puzzle import Puzzle, Searcher
import sys

def simulate(width, sample):
    state, gold_steps = sample
    puzzle = Puzzle(width, state)
    
    print("### Initial state ###")
    print(puzzle)
    searcher = Searcher(puzzle)
    steps = searcher.search()
    return "success" if steps == gold_steps else "fail"

if __name__ == "__main__":
    width = 3

    samples = [None]*6
    samples[1] = ([0,1,2,3,4,5,6,7,8], 0)
    samples[2] = ([1,2,0,3,4,5,6,7,8], 2)
    samples[3] = ([3,1,2,6,4,5,0,7,8], 2)
    samples[4] = ([1,4,2,3,7,5,6,8,0], 4)
    samples[5] = ([4,2,5,6,1,8,0,3,7], 12)

    sample_no = sys.argv[1]
    if sample_no == "all":
        results = []
        for sample in samples[1:]:
            results.append(simulate(width, sample))
        print(results)
    else:
        assert sample_no.isdigit() and int(sample_no) < 6, "Argument must be in [1,2,3,4,5,all]"
        result = simulate(width, samples[int(sample_no)])
        print(result)

