"""
[CSED342-01] Artificial Intelligence - Assignment 1

In this assignment, you will implement the A* algorithm to solve the 8-puzzle problem.
The 8-puzzle is a sliding puzzle that consists of an initial 3x3 grid with eight numbered tiles and one empty space.
The goal is to rearrange the tiles from their initial state to a goal state by sliding them into the empty space.
Refer to page 62 of 2.search

"""

import numpy as np
import time
#### Do not use other python libraries
#### You can only use python built-in functions (https://docs.python.org/3/library/functions.html).

class Puzzle:
    """
    This class represents a (width)x(width) puzzle containing (width)x(width)-1 tiles and one empty space.
    0 indicates the empty space.

    width (int) - the size of the puzzle is (width)x(width)
    state (list) - the flatten puzzle
                    ex) 0 | 1
                        2 | 3  -> [0, 1, 2, 3]
    goal (list) - the flatten goal state. the empty space is always placed at the first index.
                    ex) [0, 1, 2, 3]
    """
    def __init__(self, width, initial_state):
        self.width = width
        self.state = initial_state
        self.goal = np.arange(0, self.width**2).tolist()

    def __str__(self):
        return self.pprint()
    
    def pprint(self):
        max_space = self.width**2//10 + 1
        board = np.reshape(np.array(self.state), (self.width, self.width))
        s = ""
        for row in board:
            s += "|".join([str(v).ljust(max_space) if v > 0 else "_"*max_space for v in row])
            s += "\n"
        return s.strip()
    
    def copy(self):
        new_puzzle = Puzzle(self.width, self.state.copy())
        return new_puzzle
    
    @property
    def is_solved(self):
        """
        Returns True (boolean) if the current state of the puzzle is the goal state.
        """
        return "".join(map(str, self.state)) == "".join(map(str, self.goal))
    
    @property
    def heuristic_cost(self):
        """
        Returns the heuristic cost (int or float) for the current state.
        We will use the sum of the "Manhattan" distances for all tiles in the puzzle as the heuristic cost.
        """
        distance = 0
        # BEGIN_YOUR_ANSWER
        #### (a) Write your code ####
        # END_YOUR_ANSWER
        return distance
    
    @property
    def empty_position(self):
        """
        Returns the index of the row and column (tuple) where the empty space is located.
        """
        idx = self.state.index(0)
        i, j = idx // self.width, idx % self.width
        return (i, j)
    
    @property
    def actions(self):
        """
        Returns the list of possible actions in the current state.
        Each element in the list is a tuple of "Direction" and "Moved position".
        "Direction" can be L (left), R (right), U (up), or D (down).
        "Moved position" indicates a tuple of the row and column.
        ex) [("L", (1,0)), ("U", (0, 1))]
        """
        i, j = self.empty_position
        avaliable_directions = {"U": (i-1, j),
                                "D": (i+1, j),
                                "R": (i, j+1),
                                "L": (i, j-1)}
        actions = []
        # BEGIN_YOUR_ANSWER
        #### (b) Write your code ####
        # END_YOUR_ANSWER
        return actions

    def create_moved_puzzle(self, orig_loc, moved_loc):
        """
        Returns a new puzzle with the empty space and the neighbored tile have been swapped.
        orig_loc (tuple) - the row and column where the empty space was located.
        moved_loc (tuple) - the row and column where the empty space should be moved to.
        """
        i, j = orig_loc
        a, b = moved_loc

        orig_index = i*self.width + j
        moved_index = a*self.width + b

        new_puzzle = self.copy()
        new_puzzle.state[orig_index] = new_puzzle.state[moved_index]
        new_puzzle.state[moved_index] = 0

        return new_puzzle
    
class Node:
    """
    This class represents a node in the search tree.
    puzzle (Puzzle) - the puzzle with a specific tile state.
    moved_direction ("L", "R", "U", "D", or None) - direction of movement of the empty space in the previous state.
                                                    If there is no previous state (parent node), the value is None.
    parent (Node or None) - the parent node. If the current node is the root, the value is None.
    g (int or float) - the backward cost. If the current node is the root, the value is 0.
    f (int or float) - the sum of backward cost (g) and heuristic cost.
    """
    def __init__(self, puzzle, moved_direction=None, parent=None):
        self.puzzle = puzzle
        self.moved_direction = moved_direction

        self.parent = parent
        self.g = self.parent.g + 1 if self.parent is not None else 0
        self.f = self._set_cost()

    def __str__(self):
        return str(self.puzzle)

    def _set_cost(self):
        f = self.g + self.puzzle.heuristic_cost
        return f
    
    @property
    def node_state(self):
        return str(self)
    
    @property
    def actions(self):
        return self.puzzle.actions
    
    @property
    def is_solved(self):
        return self.puzzle.is_solved
    
    @property
    def show_path(self):
        path = []
        node = self
        while node is not None:
            path.append(node)
            node = node.parent
        
        path.reverse()
        for node in path:
            if node.moved_direction is not None:
                print(f"### Move to the {node.moved_direction} ###")
                print(node)
        print("Total number of search steps:", self.g)
        return self.g

class Searcher:
    """
    This class is a searcher that uses the A* algorithm to find a path from a given puzzle to a goal state.
    """
    def __init__(self, initial_puzzle):
        self.initial_puzzle = initial_puzzle

    def search(self):
        """
        Searchs a path to the goal state using the A* algorithm.
        Print the path using "node.show_path" when the goal state is reached.
        """
        seen_states = set()
        queue = []
        start_node = Node(self.initial_puzzle)

        # BEGIN_YOUR_ANSWER
        #### (c) Write your code ####
        # END_YOUR_ANSWER

def main():
    width = 3

    initial_state = [0,1,2,3,4,5,6,7,8]    ## sample-1
    #initial_state = [1,2,0,3,4,5,6,7,8]    ## sample-2
    #initial_state = [3,1,2,6,4,5,0,7,8]    ## sample-3
    #initial_state = [1,4,2,3,7,5,6,8,0]    ## sample-4
    #initial_state = [4,2,5,6,1,8,0,3,7]    ## sample-5

    puzzle = Puzzle(width, initial_state)
    print("### Initial state ###")
    print(puzzle)
    
    searcher = Searcher(puzzle)
    start_time = time.time()
    searcher.search()
    end_time = time.time()

    print(f"{end_time - start_time:.5f} sec")

if __name__ == "__main__":
    main()

